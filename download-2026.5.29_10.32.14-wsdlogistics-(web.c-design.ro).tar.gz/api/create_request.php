<?php
// api/create_request.php
// Clientul trimite o cerere de depanare
// POST: token, lat, lng

require_once 'config.php';
require_once 'send_notification.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Metoda nepermisa', 405);

$token = getToken();
$lat = filter_var($_POST['lat'] ?? '', FILTER_VALIDATE_FLOAT);
$lng = filter_var($_POST['lng'] ?? '', FILTER_VALIDATE_FLOAT);

if ($lat === false || $lng === false) jsonError('GPS invalid');

$db = getDB();

// Verifica ca e client
$stmt = $db->prepare("SELECT role FROM users WHERE token = ?");
$stmt->execute([$token]);
$user = $stmt->fetch();
if (!$user || $user['role'] !== 'client') jsonError('Doar clientii pot trimite cereri');

// Nu are deja cerere activa
$stmt = $db->prepare("SELECT id FROM requests WHERE client_token = ? AND status IN ('waiting','accepted')");
$stmt->execute([$token]);
if ($stmt->fetch()) jsonError('Ai deja o cerere activa');

// Creeaza cererea
$stmt = $db->prepare("
    INSERT INTO requests (client_token, status, client_lat, client_lng, created_at)
    VALUES (?, 'waiting', ?, ?, NOW())
");
$stmt->execute([$token, $lat, $lng]);
$requestId = $db->lastInsertId();

// Trimite notificare push la toti depanatorii online cu fcm_token
try {
    $col = $db->query("SHOW COLUMNS FROM users LIKE 'fcm_token'")->fetch();
    if ($col) {
        $stmt = $db->prepare("
            SELECT fcm_token FROM users 
            WHERE role = 'depanator' 
            AND online = 1 
            AND fcm_token IS NOT NULL
            AND last_seen > DATE_SUB(NOW(), INTERVAL 60 SECOND)
        ");
        $stmt->execute();
        $depanatori = $stmt->fetchAll();

        foreach ($depanatori as $dep) {
            sendPushNotification(
                $dep['fcm_token'],
                '🔧 Cerere nouă!',
                'Un client are nevoie de ajutor. Deschide aplicația pentru detalii.',
                ['request_id' => (string)$requestId]
            );
        }
    }
} catch (Exception $e) {
    // Nu blocam cererea daca notificarea esueaza
}

jsonResponse(['success' => true, 'request_id' => $requestId]);
?>
