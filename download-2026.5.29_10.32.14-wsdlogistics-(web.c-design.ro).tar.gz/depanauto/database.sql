-- DepanAuto - Schema baza de date
-- Ruleaza acest SQL in phpMyAdmin

CREATE DATABASE IF NOT EXISTS depanauto CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE depanauto;

-- Utilizatori (clienti si depanatori)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(64) UNIQUE NOT NULL,
    role ENUM('client', 'depanator') NOT NULL,
    lat DOUBLE DEFAULT NULL,
    lng DOUBLE DEFAULT NULL,
    online TINYINT(1) DEFAULT 0,
    last_seen DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Cereri de depanare
CREATE TABLE IF NOT EXISTS requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_token VARCHAR(64) NOT NULL,
    depanator_token VARCHAR(64) DEFAULT NULL,
    status ENUM('waiting', 'accepted', 'completed', 'cancelled') DEFAULT 'waiting',
    client_lat DOUBLE DEFAULT NULL,
    client_lng DOUBLE DEFAULT NULL,
    distance_km DOUBLE DEFAULT NULL,
    price_ron DOUBLE DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    accepted_at DATETIME DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL
);

-- Setari platforma (pret pe km etc.)
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(64) UNIQUE NOT NULL,
    setting_value VARCHAR(255) NOT NULL
);

-- Valori default pentru preturi
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
    ('price_per_km', '4.50'),
    ('price_fixed', '10.00'),
    ('price_min', '25.00');

-- Index pentru performanta
CREATE INDEX idx_users_token ON users(token);
CREATE INDEX idx_users_role_online ON users(role, online);
CREATE INDEX idx_requests_status ON requests(status);
CREATE INDEX idx_requests_client ON requests(client_token);
