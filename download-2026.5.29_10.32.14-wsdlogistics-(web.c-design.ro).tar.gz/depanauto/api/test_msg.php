<?php
require_once 'config.php';
$stmt = getDB()->query("SELECT * FROM request_messages ORDER BY created_at DESC LIMIT 5");
$rows = $stmt->fetchAll();
if(empty($rows)) {
    echo "Nu exista mesaje in baza de date";
} else {
    foreach($rows as $r) {
        echo "ID: ".$r['id']." | Request: ".$r['request_id']." | Mesaj: ".$r['message']." | Seen: ".$r['seen']."<br>";
    }
}
?>