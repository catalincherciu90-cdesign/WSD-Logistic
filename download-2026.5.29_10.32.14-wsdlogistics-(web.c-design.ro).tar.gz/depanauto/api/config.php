<?php
// DepanAuto - Configurare conexiune MySQL
// Modifica valorile de mai jos cu datele tale de hosting

define('DB_HOST', 'localhost');
define('DB_NAME', 'wsdlogistics');
define('DB_USER', 'wsdlogistics');
define('DB_PASS', 'wEoRlT2wwsWw4RmXVGCatI81l');
define('DB_CHARSET', 'utf8mb4');

// Conectare la baza de date
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            jsonError('Eroare conexiune baza de date: ' . $e->getMessage(), 500);
        }
    }
    return $pdo;
}

// Raspuns JSON standardizat
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError($message, $status = 400) {
    jsonResponse(['success' => false, 'error' => $message], $status);
}

// Valideaza si returneaza token-ul din request
function getToken() {
    $token = $_POST['token'] ?? $_GET['token'] ?? '';
    if (empty($token) || strlen($token) !== 64) {
        jsonError('Token invalid');
    }
    return $token;
}

// Gestioneaza OPTIONS (CORS preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    http_response_code(204);
    exit;
}
?>
