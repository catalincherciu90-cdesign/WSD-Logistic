<?php
$key = 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjFmYzM5M2UzNDhlYjRiOGFhYTBjMThhYzEyN2UyOTA2IiwiaCI6Im11cm11cjY0In0=';
$url = "https://api.openrouteservice.org/v2/directions/driving-car?api_key={$key}&start=26.10,44.42&end=26.11,44.43";

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 8,
    CURLOPT_HTTPHEADER => ['Accept: application/json'],
    CURLOPT_SSL_VERIFYPEER => false,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "HTTP Code: ".$httpCode."<br>";
echo "Curl Error: ".$error."<br>";
echo "Response: ".substr($response, 0, 500);
?>
