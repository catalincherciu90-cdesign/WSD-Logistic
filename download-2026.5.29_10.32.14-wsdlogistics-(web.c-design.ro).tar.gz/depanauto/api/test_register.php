<?php
require_once 'config.php';

$result = [];
$result['post'] = $_POST;
$result['method'] = $_SERVER['REQUEST_METHOD'];

jsonResponse($result);
?>