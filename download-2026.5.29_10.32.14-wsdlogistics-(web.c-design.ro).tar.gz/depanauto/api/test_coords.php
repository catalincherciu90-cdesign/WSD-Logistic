<?php
require_once 'config.php';
$db = getDB();
$stmt = $db->query("SELECT token, role, lat, lng, last_seen FROM users WHERE lat IS NOT NULL ORDER BY last_seen DESC LIMIT 5");
$users = $stmt->fetchAll();
foreach($users as $u) {
    echo $u['role'].' | lat:'.$u['lat'].' lng:'.$u['lng'].' | '.$u['last_seen'].'<br>';
}
?>