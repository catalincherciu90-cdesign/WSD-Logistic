<?php
require_once 'config.php';

// Ia primul depanator cu cerere acceptata
$stmt = getDB()->query("SELECT r.id, r.depanator_token FROM requests WHERE status='accepted' LIMIT 1");
$req = $stmt->fetch();

if(!$req) {
    echo "Nu exista cereri acceptate activ";
    exit;
}

echo "Request ID: ".$req['id']."<br>";
echo "Depanator token: ".substr($req['depanator_token'],0,10)."...<br>";

// Trimite mesaj test
$stmt = getDB()->prepare("INSERT INTO request_messages (request_id, sender_role, message) VALUES (?, 'depanator', 'Test mesaj')");
$stmt->execute([$req['id']]);
echo "Mesaj inserat cu succes! ID: ".getDB()->lastInsertId();
?>