<?php
require_once 'config.php';

$stmt = getDB()->prepare("SELECT email, role, status FROM users WHERE role='depanator' LIMIT 5");
$stmt->execute();
$users = $stmt->fetchAll();

if(empty($users)) {
    echo "Nu exista niciun depanator in baza de date";
} else {
    foreach($users as $u) {
        echo $u['email'] . ' | ' . $u['role'] . ' | ' . ($u['status']??'null') . '<br>';
    }
}
?>